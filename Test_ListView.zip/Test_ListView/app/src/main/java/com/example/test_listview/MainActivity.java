package com.example.test_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    // Array of strings...
    ListView simpleList;
    Intent MyIntent;
    static List<Task> taches;


    @Override   protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyIntent = new Intent(this, Main3Activity.class);

        /* DATA */
        Task A = new Task("A");
        Task B = new Task("B");
        Task C = new Task("C");
        Task D = new Task("D");
        Task T = new Task("T");
        Task toto = new Task ("toto");
        Task Freddy = new Task ("Freddy");
        Task Lola = new Task ("Lola");
        Task superNova = new Task ("superNova");
        Task marche = new Task ("marche");
        Task go = new Task ("go");
        Task start = new Task ("start");
        Task end = new Task ("end");
        Task middle = new Task ("middle");
        Task Nice = new Task ("Nice");


        T.addChild(A);
        T.addChild(B);
        T.addChild(C);

        T.addChild(toto);
        T.addChild(Freddy);
        T.addChild(Lola);
        T.addChild(superNova);
        T.addChild(marche);
        T.addChild(end);
        T.addChild(middle);
        T.addChild(Nice);

        C.addChild(Freddy);
        A.addChild(D);
        D.addChild(marche);
        D.addChild(go);
        B.addChild(end);
        superNova.addChild(start);
        B.addChild(Lola);
        B.addChild(toto);
        end.addChild(Nice);
        end.addChild(middle);


        Task current = T;
        //afficher T
        List<Task> soustaches_t = current.getChilds();
        MainActivity.taches = soustaches_t;

        /* END DATA */


        simpleList = (ListView) findViewById(R.id.simpleListView);
        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(), soustaches_t);
        simpleList.setAdapter(customAdapter);

        simpleList.setOnItemClickListener(CLickList);

    }


    private AdapterView.OnItemClickListener CLickList = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView parent, View view, int position, long id) {
            // String itemValue = (String) simpleList.getItemAtPosition(position);

            Context context = view.getContext();//.getApplicationContext();
            Task task = (Task) parent.getAdapter().getItem(position);
            String text = "Task " + task.getName() + " !";

           // MyIntent.putExtra("Task_key", task.getName());
            MyIntent.putExtra("Task_key", position);
            startActivity(MyIntent);

        }
    };




}
