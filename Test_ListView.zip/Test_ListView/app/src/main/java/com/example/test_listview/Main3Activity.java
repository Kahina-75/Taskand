package com.example.test_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class Main3Activity extends AppCompatActivity {
    // Array of strings...
    ListView simpleList;
    //Intent MyIntent;

    @Override   protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        int position = intent.getIntExtra("Task_key", 0);

        /* DATA */
        Task T = MainActivity.taches.get(position);
        // Task T = new Task("T");


        Task current = T;
        //afficher T
        List<Task> soustaches_t = current.getChilds();
        /* END DATA */


        simpleList = (ListView) findViewById(R.id.simpleListView);
        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(), soustaches_t);
        simpleList.setAdapter(customAdapter);

    }

}
